package com.ToDoList.ToDoList.Controllers;

import com.ToDoList.ToDoList.models.Person;
import com.ToDoList.ToDoList.models.Project;
import com.ToDoList.ToDoList.models.Task; // Импорт класса Task
import com.ToDoList.ToDoList.repositories.PersonRepository;
import com.ToDoList.ToDoList.repositories.ProjectRepository;
import com.ToDoList.ToDoList.repositories.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PathVariable;

import jakarta.servlet.http.HttpSession;
import java.util.List;

@org.springframework.stereotype.Controller
public class Controller {

    @Autowired
    private PersonRepository personRepository;

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private TaskRepository taskRepository;

    // Главная страница выхода
    @GetMapping("/")
    public String home() {
        return "log_out"; // Возвращаем страницу выхода
    }

    // Главная страница пользователя
    @GetMapping("/index")
    public String index(HttpSession session, Model model) {
        Long currentUserId = (Long) session.getAttribute("currentUserId");
        if (currentUserId != null) {
            Iterable<Project> projects = projectRepository.findAllByOwnerId(currentUserId);
            model.addAttribute("projects", projects);
            return "index"; // Возвращаем главную страницу
        }
        return "log_out"; // Если пользователь не авторизован, перенаправляем на страницу выхода
    }

    // Регистрация нового пользователя
    @PostMapping("/register")
    public String register(@RequestParam String username, @RequestParam String email, @RequestParam String password, HttpSession session) {
        if (personRepository.findByEmail(email) != null) {
            return "log_out"; // Пользователь с таким email уже существует
        }

        Person person = new Person();
        person.setUsername(username);
        person.setEmail(email);
        person.setPassword(password);
        personRepository.save(person);

        session.setAttribute("currentUserId", person.getId()); // Сохраняем ID пользователя в сессии

        return "redirect:/index"; // Перенаправление на главную страницу
    }

    // Вход в систему
    @PostMapping("/login")
    public String login(@RequestParam String email, @RequestParam String password, Model model, HttpSession session) {
        Person person = personRepository.findByEmailAndPassword(email, password);
        if (person != null) {
            session.setAttribute("currentUserId", person.getId());
            return "redirect:/index"; // Успешный вход
        }
        model.addAttribute("error", "Неверный email или пароль");
        return "log_out"; // Ошибка входа
    }

    // Страница пользователя "Мои проекты"
    @GetMapping("/my")
    public String myPage(HttpSession session, Model model) {
        Long currentUserId = (Long) session.getAttribute("currentUserId");
        if (currentUserId != null) {
            Iterable<Project> projects = projectRepository.findAllByOwnerId(currentUserId);
            model.addAttribute("projects", projects);
            return "index"; // Возвращаем страницу с проектами
        }
        return "log_out"; // Если пользователь не авторизован
    }

    // Создание нового проекта
    @PostMapping("/createProject")
    public String createProject(@RequestParam String projectName, HttpSession session) {
        Long currentUserId = (Long) session.getAttribute("currentUserId");
        if (currentUserId != null) {
            Person owner = personRepository.findById(currentUserId).orElse(null);
            if (owner != null) {
                Project project = new Project();
                project.setName(projectName);
                project.setOwner(owner);
                projectRepository.save(project);
            }
        }
        return "redirect:/index"; // Перенаправление на главную страницу
    }

    // Просмотр дашборда проекта
    @GetMapping("/project/{projectId}")
    public String viewDashboard(@PathVariable Long projectId, HttpSession session, Model model) {
        Long currentUserId = (Long) session.getAttribute("currentUserId");
        if (currentUserId != null) {
            Project project = projectRepository.findById(projectId)
                    .orElseThrow(() -> new IllegalArgumentException("Некорректный ID проекта: " + projectId));

            // Проверяем, принадлежит ли проект текущему пользователю
            if (!project.getOwner().getId().equals(currentUserId)) {
                return "redirect:/index"; // Если проект не принадлежит текущему пользователю, перенаправляем его
            }

            List<Task> tasks = taskRepository.findByProjectId(projectId);

            model.addAttribute("project", project);
            model.addAttribute("tasks", tasks);

            return "dashboard"; // Возвращаем страницу дашборда
        }
        return "log_out"; // Если пользователь не авторизован
    }
}
