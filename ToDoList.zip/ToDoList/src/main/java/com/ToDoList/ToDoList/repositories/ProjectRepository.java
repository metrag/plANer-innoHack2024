package com.ToDoList.ToDoList.repositories;

import com.ToDoList.ToDoList.models.Project;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ProjectRepository extends CrudRepository<Project, Long> {
    // Находим проекты по ID пользователя
    List<Project> findAllByOwnerId(Long ownerId);
}
