package com.ToDoList.ToDoList.repositories;

import com.ToDoList.ToDoList.models.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonRepository extends JpaRepository<Person, Long> {
    // Метод для поиска пользователя по email
    Person findByEmail(String email);

    // Метод для поиска пользователя по email и паролю
    Person findByEmailAndPassword(String email, String password);
}
